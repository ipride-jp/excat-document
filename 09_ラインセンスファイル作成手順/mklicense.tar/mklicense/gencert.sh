#!/bin/bash
#KEYLEN=4096
CONFIG=openssl.cnf

echo -n 'enter the name of file: '
read file

if [ -s CA/private/${file}key.pem ];
then
  echo "the name [$file] is duplicated!"
  exit;
fi

echo -n "generating private-key..."
openssl genrsa -out ${file}key.pem $KEYLEN
if [ ! -s ${file}key.pem ];
then
  echo "failed to generate key!"
  exit;
fi
echo "done."

echo -n "Country Name (e.g., [JP], [CN], ...): "
read C
export C

echo -n "Prefecture or state (e.g., [Tokyo], [Shanghai], ...): "
read ST
export ST

echo -n "City (e.g., [Chuo], [Xxxx], ...): "
read L
export L

echo -n "Company (e.g., [iPride Co., Ltd.]): "
read O
export O

echo -n "Username: "
read CN
export CN

echo -n "Mail address: "
read emailAddress
export emailAddress

echo -n "Software version (e.g., [Excat<=1.0]): "
read info
export info

echo -n "MAC address (e.g., [01:23:45:67:89:AB]: "
read macAddress
export macAddress

echo -n "generating certificate request... "
openssl req -out ${file}req.pem -new -key ${file}key.pem -config $CONFIG -batch
if [ ! -s ${file}req.pem ];
then
  echo "failed to generate request!"
  exit;
fi
echo "done."


echo -n "Certificate is valid from (YYMMDDhhmmss): "
read startDate
export startDate="${startDate}Z"

echo -n "Certificate is valid to (YYMMDDhhmmss): "
read endDate
export endDate="${endDate}Z"

echo -n "generating certificate (i.e., license file)... "
openssl ca -config $CONFIG -startdate $startDate -enddate $endDate -policy policy_excat -keyfile CA/private/cakey.pem -cert CA/cacert.pem -in ${file}req.pem -out ${file}cert.pem -notext -batch
if [ ! -s ${file}cert.pem ];
then
  echo "failed to generate certificate!"
  exit;
fi;
echo "done."

echo -n "postprocessing ..."
cp ${file}key.pem CA/private/
rm ${file}key.pem
rm ${file}req.pem
mv ${file}cert.pem ${file}.pem
echo "done."

echo "conguraturation: license file ${file}.pem is now generated!"
echo "caution: please backup the CA/ directory immediately!"

# the end of file
